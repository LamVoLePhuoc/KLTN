`include "../src/mul_div/divider/divider_64bit.sv"
`include "../src/mul_div/multiplier/half_adder.sv"
`include "../src/mul_div/multiplier/twos_comp_128bit.sv"
`include "../src/mul_div/multiplier/twos_comp_64bit.sv"
`include "../src/mul_div/multiplier/CLA_4bit.sv"
`include "../src/mul_div/multiplier/CLA_8bit.sv"
`include "../src/mul_div/multiplier/CLA_16bit.sv"
`include "../src/mul_div/multiplier/CLA_32bit.sv"
`include "../src/mul_div/multiplier/CLA_64bit.sv"
`include "../src/mul_div/multiplier/vedic_mult_2bit.sv"
`include "../src/mul_div/multiplier/vedic_mult_4bit.sv"
`include "../src/mul_div/multiplier/vedic_mult_8bit.sv"
`include "../src/mul_div/multiplier/vedic_mult_16bit.sv"
`include "../src/mul_div/multiplier/vedic_mult_32bit.sv"
`include "../src/mul_div/multiplier/vedic_mult_64bit.sv"
`include "../src/mul_div/multiplier/signed_vedic_mult_64bit.sv"
`include "../src/mul_div/md_res_mux.sv"
`include "../src/mul_div/mul_div_ctrl_unit.sv"
`include "../src/mul_div/mul_div_top.sv"
`include "../src/add4.sv"
`include "../src/alu.sv"
`include "../src/br_mux.sv"
`include "../src/ex_res_mux.sv"
`include "../src/brcomp.sv"
`include "../src/ctrl_unit.sv"
`include "../src/forward1mux.sv"
`include "../src/forward2mux.sv"
`include "../src/bridgemux.sv"
`include "../src/hazard_unit.sv"
`include "../src/immGen.sv"
`include "../src/instr_rom.sv"
`include "../src/lsu.sv"
`include "../src/op_a_mux.sv"
`include "../src/op_b_mux.sv"
`include "../src/pc_reg.sv"
`include "../src/reg_dec.sv"
`include "../src/issue_cmd.sv"
`include "../src/reg_decode_execute.sv"
`include "../src/reg_execute_memory.sv"
`include "../src/reg_fetch_decode.sv"
`include "../src/reg_memory_writeback.sv"
`include "../src/regfile.sv"
`include "../src/rs1d_mux.sv"
`include "../src/rs2d_mux.sv"
`include "../src/wb_mux.sv"
`include "../src/pipeline.sv"

module pipeline_tb;
	timeunit 1ns; timeprecision 1ps;

    logic clk_i, rst_ni;
	
	pipeline dut (
		.clk_i(clk_i),
		.rst_ni(rst_ni));
	
	initial begin
		rst_ni       = 1'b0;
		$dumpfile("dump.vcd");
		$dumpvars;
	end
	
	initial begin
    	clk_i = 1'b0;
	 	forever #5 clk_i = !clk_i;
   	end
	
	initial begin
		#8
		rst_ni   = 1'b1;
		
		#200000	$finish;
	end
endmodule 