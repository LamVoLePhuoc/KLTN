module issue_cmd (
    input  logic [31:0] instr_f,
    output logic [31:0] issue_to_CPU,
    output logic [31:0] issue_to_FPU
);
    timeunit 1ns; timeprecision 1ps;
    
    // Extract opcode field (RISC-V opcode = bits [6:0])
    logic [6:0] opcode;

    always_comb begin
        opcode = instr_f[6:0];
    end

    // Combinational logic with clock and async reset
    always_comb begin: for_CPU
        case (opcode)
            // --- Integer Instructions 32 ---
            7'b0110011, // R-type integer (ADD, SUB, etc.)
            7'b0010011, // I-type integer (ADDI, ANDI, etc.)
            7'b0000011, // Load integer
            7'b0100011, // Store integer
            7'b1100011, // Branch
            7'b1101111, // JAL
            7'b1100111, // JALR
            7'b0110111, // LUI
            7'b0010111, // AUIPC
            // --- Interger Instruction 64 ---
            7'b0011011, // RV64 *W I-type command
            7'b0111011, // RV64 *W R-type command
            7'b1110011, // CSR commands
            7'b0001111: // FENCE commands
            begin
                issue_to_CPU <= instr_f[31:0];
            end

            default: begin
                issue_to_CPU <= 32'b0;
            end
        endcase
    end

    always_comb begin: for_FPU
        case (opcode)
            // --- Floating-Point Instructions ---
            7'b1010011, // FPU compute (ADD.S, MUL.S, etc.)
            7'b0000111, // Load floating-point (FLW, FLD)
            7'b0100111, // Store floating-point (FSW, FSD)
            7'b1000011, // FMADD.S
            7'b1000111, // FMSUB.S
            7'b1001011, // FNMSUB.S
            7'b1001111: // FNMADD.S
            begin
                issue_to_FPU <= instr_f[31:0];
            end

            default: begin
                issue_to_FPU <= 32'b0;
            end
        endcase
    end

endmodule: issue_cmd