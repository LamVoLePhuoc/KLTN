module lsu (
    input clk_i, rst_ni, st_en,
    input [11:0] addr,
    input [3:0] byte_en,
    input [2:0] ld_sel,
    input [63:0] st_data,
    output [63:0] ld_data
);
    timeunit 1ns; timeprecision 1ps;
    
    logic [63:0] ld_wire;
    logic [63:0] mem[(2**12)];

    always_ff @(posedge clk_i) begin
        if (!rst_ni) begin
            for (int i = 0; i < (2**12); i++) begin
                // mem[i] <= '0;
                mem[i] <= 'd36;   // NVL TODO: checkkkkkkkkkkkkkk
            end
        end
        else if (st_en) begin
            if (byte_en == 4'b0001) begin
                mem[addr][7:0] <= st_data[7:0];
            end
            else if (byte_en == 4'b0011) begin
                mem[addr][15:0] <= st_data[15:0];
            end
            else if (byte_en == 4'b1111) begin
                mem[addr][31:0] <= st_data[31:0];
            end
            else if (byte_en == 4'b0111) begin
                mem[addr][63:0] <= st_data[63:0];
            end
            else begin
                mem[addr] <= st_data;
            end
        end
    end

    assign ld_wire = mem[addr];

    ld_sel_mux lsm (
        .LD(ld_wire),
        .LW(ld_wire[31:0]),
        .LWU(ld_wire[31:0]),
        .LB(ld_wire[7:0]),
        .LBU(ld_wire[7:0]),
        .LH(ld_wire[15:0]),
        .LHU(ld_wire[15:0]),
        .ld_sel(ld_sel),
        .ld_data(ld_data));

endmodule

module ld_sel_mux (
    input [63:0] LD,
    input [31:0] LW, LWU,
    input [7:0] LB, LBU,
    input [15:0] LH, LHU,
    input [2:0] ld_sel,
    output [63:0] ld_data
);
    timeunit 1ns; timeprecision 1ps;

    assign ld_data = (ld_sel == 3'h0) ? {56'b0, LBU} :
                     (ld_sel == 3'h1) ? {48'b0, LHU} :
                     (ld_sel == 3'h2) ? {{56{LB[7]}}, LB} :
                     (ld_sel == 3'h3) ? LD :
                     (ld_sel == 3'h4) ? {{48{LH[15]}}, LH} :
                     (ld_sel == 3'h5) ? {32'b0, LWU} :
                     (ld_sel == 3'h6) ? {{32{LW[31]}}, LW} : LD;

endmodule