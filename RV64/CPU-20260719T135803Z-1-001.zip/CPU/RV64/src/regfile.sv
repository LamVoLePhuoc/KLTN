module regfile (
    input wire clk_i,
    input wire rst_ni,
    input wire [4:0] rs1_addr,
    input wire [4:0] rs2_addr,
    input wire [4:0] rd_addr,
    input wire [63:0] rd_data,
    input wire rd_wren,
    output wire [63:0] rs1_data,
    output wire [63:0] rs2_data,

    // For bridge to FPU
    input  logic        bridge_wren_i,
    input  logic [4:0]  bridge_wr_addr_i,
    input  logic [63:0] bridge_wr_data_i,
    
    input  logic        bridge_rden_i,
    input  logic [4:0]  bridge_rd_addr_i,
    output logic [63:0] bridge_rd_data_o
);
    timeunit 1ns; timeprecision 1ps;
    
    reg [63:0] registers [0:31];

    always @(negedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
            for (int i = 0; i < 32; i = i + 1) begin
                // registers[i] <= 64'h0000000000000000;
                // registers[i] <= $realtobits($itor(i));       // NVL TODO for testing only
                registers[i] <= (i%2 == 0) ? i : (-i);       // NVL TODO for testing only
            end
        end 
        else begin
            if (rd_wren && rd_addr != 0) begin
                registers[rd_addr] <= rd_data;
            end

            if (bridge_wren_i && (bridge_wr_addr_i != 5'd0)) begin
                registers[bridge_wr_addr_i] <= bridge_wr_data_i;
            end
        end 
    end

    assign rs1_data = registers[rs1_addr];
    assign rs2_data = registers[rs2_addr];
    assign bridge_rd_data_o = (bridge_rden_i) ? registers[bridge_rd_addr_i] : 'z;
endmodule
