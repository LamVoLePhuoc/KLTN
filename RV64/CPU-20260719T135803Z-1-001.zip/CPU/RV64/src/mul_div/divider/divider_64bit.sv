module divider_64bit(
    input  logic [63:0] op_a, op_b,
    input  logic [1:0]  mode,
    output logic [63:0] res
);
    
    timeunit 1ns; timeprecision 1ps;

    localparam DIV      = 2'b00;
    localparam DIVU     = 2'b01;
    localparam REM      = 2'b10;
    localparam REMU     = 2'b11;

    always_comb begin
        case (mode)
            DIV: begin
                if (~(|op_b)) begin    // Dividend = x, Divisor = 0
                    res = 64'hFFFF_FFFF_FFFF_FFFF;
                end
                else if ((op_a[63]) & (~(|op_a[62:0])) & (&op_b)) begin    // Dividend = most negative num, Divisor = -1
                    res = op_a;
                end
                else begin
                    res = $signed(op_a) / $signed(op_b);
                end
            end 
            DIVU: begin
                if (~(|op_b)) begin    // Dividend = x, Divisor = 0
                    res = 64'hFFFF_FFFF_FFFF_FFFF;
                end
                else begin
                    res = $unsigned(op_a) / $unsigned(op_b);
                end
            end
            REM: begin
                if (~(|op_b)) begin    // Dividend = x, Divisor = 0
                    res = op_a;
                end
                else if ((op_a[63]) & (~(|op_a[62:0])) & (&op_b)) begin    // Dividend = most negative num, Divisor = -1
                    res = 64'd0;
                end
                else begin
                    res = $signed(op_a) % $signed(op_b);
                end
            end
            REMU: begin
                if (~(|op_b)) begin    // Dividend = x, Divisor = 0
                    res = op_a;
                end
                else begin
                    res = $unsigned(op_a) % $unsigned(op_b);
                end
            end
            default: begin
                res = 64'd0;
            end 
        endcase
    end
endmodule