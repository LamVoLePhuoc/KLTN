module half_adder(a, b, sum, carry);

    timeunit 1ns; timeprecision 1ps;

    input a, b;
    output sum, carry;

    assign sum = a ^ b;
    assign carry = a & b;

endmodule
