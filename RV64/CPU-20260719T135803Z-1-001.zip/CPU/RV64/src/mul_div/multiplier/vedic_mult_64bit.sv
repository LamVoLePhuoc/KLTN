module vedic_mult_64bit(a, b, out);

    timeunit 1ns; timeprecision 1ps;

    //declaring input and output variables
    input [63:0] a, b;
    output [127:0] out;

    //declaring wires for 32x32 vedic multiplier output
    wire [63:0] out_ved1, out_ved2, out_ved3, out_ved4;

    //declaring wires for CLA
    wire c1, c2, c3;
    wire [63:0] cla_sum1, cla_sum2, cla_sum3;
    wire or_carry;

    //instantiating 32x32 vedic multiplier blocks
    vedic_mult_32bit v1(a[31:0], b[31:0], out_ved1);
    vedic_mult_32bit v2(a[31:0], b[63:32], out_ved2);
    vedic_mult_32bit v3(a[63:32], b[31:0], out_ved3);
    vedic_mult_32bit v4(a[63:32], b[63:32], out_ved4);

    assign or_carry = c1 + c2;

    //instantiating CLA blocks
    CLA_64bit cla1(out_ved2, out_ved3, 1'b0, cla_sum1, c1);
    CLA_64bit cla2({32'b0, out_ved1[63:32]}, cla_sum1, 1'b0, cla_sum2, c2);
    CLA_64bit cla3({31'b0, or_carry, cla_sum2[63:32]}, out_ved4, 1'b0, cla_sum3, c3);

    //final output logic
    assign out = {cla_sum3, cla_sum2[31:0], out_ved1[31:0]};

endmodule
