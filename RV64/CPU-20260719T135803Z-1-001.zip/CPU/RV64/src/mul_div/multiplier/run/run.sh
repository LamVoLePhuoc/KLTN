if [ ! -d "./my_work_dir" ]; then
    mkdir ./my_work_dir
fi

xrun -work WORK -access +r ./signed_vedic_mult_64bit_tb.sv -l ./my_work_dir/xrun.log -xmlibdirpath ./my_work_dir > ./my_work_dir/run.log
