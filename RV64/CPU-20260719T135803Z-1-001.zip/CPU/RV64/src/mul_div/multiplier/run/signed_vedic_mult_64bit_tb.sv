`include "../twos_comp_64bit.sv"
`include "../twos_comp_128bit.sv"
`include "../half_adder.sv"
`include "../CLA_4bit.sv"
`include "../CLA_8bit.sv"
`include "../CLA_16bit.sv"
`include "../CLA_32bit.sv"
`include "../CLA_64bit.sv"
`include "../vedic_mult_2bit.sv"
`include "../vedic_mult_4bit.sv"
`include "../vedic_mult_8bit.sv"
`include "../vedic_mult_16bit.sv"
`include "../vedic_mult_32bit.sv"
`include "../vedic_mult_64bit.sv"
`include "../signed_vedic_mult_64bit.sv"

module signed_vedic_mult_64bit_tb();

    timeunit 1ns; timeprecision 1ps;

    logic [63:0] a, b;
    logic [127:0] out;
    logic [1:0] mode;
    bit [127:0] temp_a, temp_b;
    logic [127:0] expected;
    longint unsigned matched, mismatched;

    signed_vedic_mult_64bit DUT(.op_a(a), .op_b(b), .mode(mode), .res(out));

    initial begin
        matched = 0;
        mismatched = 0;
        #10ns;

        for (int mode_val = 0; mode_val < 4; mode_val++) begin
            mode = mode_val[1:0];
            $display("\n===================== TESTING MODE = %b =====================", mode);
            case (mode)
                2'b00, 2'b01: $display("Mode description: signed x signed");
                2'b10: $display("Mode description: signed x unsigned");
                2'b11: $display("Mode description: unsigned x unsigned");
            endcase

            repeat (100) begin
                a = {$random, $random};
                b = {$random, $random};

                case (mode)
                    2'b00, 2'b01: begin // signed x signed
                        temp_a = {{64{a[63]}}, a};
                        temp_b = {{64{b[63]}}, b};
                        expected = $signed(temp_a) * $signed(temp_b);
                        #1;
                        $write("@%0t mode=%b (sxs) a=%0d, b=%0d, out=%0d, expected=%0d", $time, mode, $signed(a), $signed(b), $signed(out), $signed(expected));
                    end
                    2'b10: begin // signed x unsigned
                        temp_a = {{64{a[63]}}, a};
                        temp_b = {64'b0, b};
                        expected = $signed(temp_a) * $unsigned(temp_b);
                        #1;
                        $write("@%0t mode=%b (sxu) a=%0d, b=%0d, out=%0d, expected=%0d", $time, mode, $signed(a), $unsigned(b), $signed(out), $signed(expected));
                    end
                    2'b11: begin // unsigned x unsigned
                        temp_a = {64'b0, a};
                        temp_b = {64'b0, b};
                        expected = $unsigned(temp_a) * $unsigned(temp_b);
                        #1;
                        $write("@%0t mode=%b (uxu) a=%0d, b=%0d, out=%0d, expected=%0d", $time, mode, $unsigned(a), $unsigned(b), $unsigned(out), $unsigned(expected));
                    end
                endcase

                if (out === expected) begin
                    $display("\tMATCHED");
                    matched++;
                end else begin
                    $display("\tMISMATCHED");
                    mismatched++;
                end

                #4;
            end
        end

        $display("\n========================= RESULT =========================");
        $display("| Matched:    %0d test(s)", matched);
        $display("| Mismatched: %0d test(s)", mismatched);
        $display("==========================================================");
        $finish;
    end

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0);
    end

endmodule
