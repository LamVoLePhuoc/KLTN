`timescale 1ps/1ps

module write_back(
    input [31:0] alu_result, data_mem, pc_plus_4,
    input [1:0] wb_sel,
    output reg [31:0] wb_data_out
);
    always @(*) begin
        case(wb_sel)
            2'b00: wb_data_out = data_mem;
            2'b01: wb_data_out = alu_result;
            2'b10: wb_data_out = pc_plus_4;
            default: wb_data_out = 32'h0;
        endcase
    end
    
endmodule