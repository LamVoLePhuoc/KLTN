module fp_lsu #(
    parameter   DATA_WIDTH = 64,
    parameter   ADDR_WIDTH = 6
) (
    input  logic                  clk,
    input  logic                  rst_n,
    input  logic                  ld_sel,
    input  logic                  wren,
    input  logic [ADDR_WIDTH-1:0] addr,
    input  logic [DATA_WIDTH-1:0] din,
    output logic [DATA_WIDTH-1:0] dout
);
    timeunit 1ns; timeprecision 1ps;

    (* dont_touch = "true" *) fp_ram #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) ram (
        .clk(clk),
        .rst_n(rst_n),
        .we(wren),
        .re(ld_sel),
        .addr(addr),
        .data_in(din),
        .data_out(dout)
    );

endmodule

module fp_ram #(
    parameter DATA_WIDTH = 64,
    parameter ADDR_WIDTH = 6
) (
    input  logic                  clk,
    input  logic                  rst_n,
    input  logic                  we,
    input  logic                  re,
    input  logic [ADDR_WIDTH-1:0] addr,
    input  logic [DATA_WIDTH-1:0] data_in,
    output logic [DATA_WIDTH-1:0] data_out
);

    timeunit 1ns; timeprecision 1ps;

    integer debug_fhandle;  // For debug log

    logic [DATA_WIDTH-1:0] mem [(2**ADDR_WIDTH)];

    logic [DATA_WIDTH-1:0] temp;
    
    always_ff @(posedge clk) begin
        /*if (!rst_n) begin
            load_backdoor_values(debug_fhandle);
        end
        else */if (we && (addr < (2**ADDR_WIDTH))) begin    // Using backdoor instead of reset
            mem[addr] <= data_in;
        end
    end
    
    always_ff @(negedge clk) begin  // Temporary method of using negedge
        if (we) begin
            temp <= temp;
        end
        else if (re) begin
            temp <= mem[addr];
        end
        else begin
            temp <= '0;
        end
    end
    
    assign data_out = temp;

endmodule