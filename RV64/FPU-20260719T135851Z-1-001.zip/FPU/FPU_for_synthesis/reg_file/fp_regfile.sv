module fp_regfile #(
  parameter DataWidth  = 64,	// Double precision
  parameter NumRegs    = 32,	// 32 registers
  parameter IndexWidth = 5  	// logarit base 2 of NumRegs
) (
  input  logic                  clk,
  input	 logic				    reset,
  input  logic                  writeEn,
  input  logic [IndexWidth-1:0] writeAddr,
  input  logic [DataWidth-1:0]  writeData,
  input  logic [IndexWidth-1:0] readAddr1,
  input  logic [IndexWidth-1:0] readAddr2,
  input  logic [IndexWidth-1:0] readAddr3,
  output logic [DataWidth-1:0]  readData1,
  output logic [DataWidth-1:0]  readData2,
  output logic [DataWidth-1:0]  readData3,
  output logic [DataWidth-1:0]  readData4               //Output ph�p chia
);
    timeunit 1ns; timeprecision 1ps;
    
    // Declare the register array
    logic [DataWidth-1:0] regs[NumRegs];

    // Write logic	
    always_ff @(negedge clk or negedge reset) begin
		  if (reset == 1'b0) begin
				integer i;
				for (i = 0; i < NumRegs; i = i + 1) begin
					  regs[i] <= '0;
				end
					regs[2] <= 64'b0100000000001000000000000000000000000000000000000000000000000000;   //2
                    regs[5] <= 64'b0100000001000010010011001100110011001100110011001100110011001101;   //36.6			
		  end
        else if ((writeEn == 1'b1) & (writeAddr != '0)) begin
            regs[writeAddr] <= writeData;
        end
    end
    
    assign readData1 = regs[readAddr1];
    assign readData2 = regs[readAddr2];
    assign readData3 = regs[readAddr3];
    assign readData4 = regs[6];
endmodule
