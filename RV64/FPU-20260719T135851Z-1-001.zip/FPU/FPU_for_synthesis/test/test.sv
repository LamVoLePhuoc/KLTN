  output lzc_64_in_type lzc1_64_i;
  output lzc_64_out_type lzc1_64_o;
  output lzc_64_in_type lzc2_64_i;
  output lzc_64_out_type lzc2_64_o;
  output lzc_64_in_type lzc3_64_i;
  output lzc_64_out_type lzc3_64_o;
  output lzc_64_in_type lzc4_64_i;
  output lzc_64_out_type lzc4_64_o;

  output lzc_256_in_type lzc_256_i;
  output lzc_256_out_type lzc_256_o;

  output fp_ext_in_type fp_ext1_i;
  output fp_ext_out_type fp_ext1_o;
  output fp_ext_in_type fp_ext2_i;
  output fp_ext_out_type fp_ext2_o;
  output fp_ext_in_type fp_ext3_i;
  output fp_ext_out_type fp_ext3_o;

  output fp_cmp_in_type fp_cmp_i;
  output fp_cmp_out_type fp_cmp_o;
  output fp_max_in_type fp_max_i;
  output fp_max_out_type fp_max_o;
  output fp_sgnj_in_type fp_sgnj_i;
  output fp_sgnj_out_type fp_sgnj_o;
  output fp_fma_in_type fp_fma_i;
  output fp_fma_out_type fp_fma_o;
  output fp_rnd_in_type fp_rnd_i;
  output fp_rnd_out_type fp_rnd_o;

  output fp_cvt_f2f_in_type fp_cvt_f2f_i;
  output fp_cvt_f2f_out_type fp_cvt_f2f_o;
  output fp_cvt_f2i_in_type fp_cvt_f2i_i;
  output fp_cvt_f2i_out_type fp_cvt_f2i_o;
  output fp_cvt_i2f_in_type fp_cvt_i2f_i;
  output fp_cvt_i2f_out_type fp_cvt_i2f_o;

  output fp_mac_in_type fp_mac_i;
  output fp_mac_out_type fp_mac_o;
  output fp_fdiv_in_type fp_fdiv_i;
  output fp_fdiv_out_type fp_fdiv_o;