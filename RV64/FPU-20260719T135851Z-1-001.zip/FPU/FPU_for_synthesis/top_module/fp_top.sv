import fp_wire::*;
module fp_top #(
  parameter DataWidth  = 64,	
  parameter NumRegs    = 32,	
  parameter IndexWidth = 5  	
)(
    input logic        clk,
    input logic        rst_n,
    input logic [31:0] instr_i,
    output logic       stall_i,
    output logic [DataWidth-1:0]  readData4  

);

    timeunit 1ns; timeprecision 1ps;
    // DEC stage
    logic [31:0]           instr;

    //      fp_control_unit
    logic [19:0]           fp_opcode;
    logic                  en;
    logic                  reg_write;
    logic                  fmt_sel;
    logic                  rm_sel;
    logic                  ld_sel;
    logic                  wb_sel;
    logic                  wren;
    logic [4:0]            shift_reg_addr;
    logic                  div_sqrt;
    logic                  bridge_wren;
    logic                  bridge_rden;

    //      fp_reg_file
    logic [IndexWidth-1:0] readAddr1;
    logic [IndexWidth-1:0] readAddr2;
    logic [IndexWidth-1:0] readAddr3;
    logic [DataWidth-1:0]  readData1;
    logic [DataWidth-1:0]  readData2;
    logic [DataWidth-1:0]  readData3;
    logic [DataWidth-1:0]  readData4;       //Output cua reg[6]

    //      fp_sign_extend
    logic [11:0]           in_sign_extend;
    logic [63:0]           out_sign_extend;

    // EX stage
    logic [19:0]           fp_opcode_d;
    logic                  en_d;
    logic                  fmt_sel_d;
    logic                  rm_sel_d;
    logic                  wb_sel_d;
    logic                  wren_d;
    logic [4:0]            writeAddr_d;
    logic [2:0]            rm_d;
    logic [1:0]            fmtLS_d;
    logic [1:0]            fmt_d;
    logic [63:0]           rdData1_d;
    logic [63:0]           rdData2_d;
    logic [63:0]           rdData3_d;
    logic [2:0]            dyn_rm_d;
    logic [63:0]           imm_d;
    logic [4:0]            rdAddr1_d;
    logic [4:0]            rdAddr2_d;
    logic [4:0]            rdAddr3_d;
    logic                  bridge_wren_d;
    logic                  reg_write_e;
    logic [4:0]            writeAddr_e;
    logic                  ld_sel_e;
    logic                  wb_sel_e;
    logic                  wren_e;

    //      fp_unit
    logic [1:0]            fmt;
    logic [2:0]            rm;
    logic [63:0]           data1;
    logic [63:0]           data2;
    logic [63:0]           data3;
    fp_unit_in_type        fp_unit_i;
    fp_unit_out_type       fp_unit_o;  
    logic [63:0]           result;
    logic [4:0]            flags;
    logic                  ready; 

    //      fp_adder
    logic [63:0]           imm_e;

    // MEM
    logic                  reg_write_m;
    logic [4:0]            writeAddr_m;
    logic                  ld_sel_m;
    logic                  wb_sel_m;
    logic                  wren_m;
    logic [63:0]           res_m;
    logic [4:0]            flag_m;
    logic                  ready_m;
    logic [63:0]           din;
    logic [63:0]           addr;
    logic                  bridge_wren_m;

    //      fp_lsu
    logic [63:0]           mem2lsu;

    // WB stage
    logic                  reg_write_o;
    logic [4:0]            writeAddr_o;
    logic [DataWidth-1:0]  writeData;
    logic                  wb_sel_o;
    logic [63:0]           res_o;
    logic [4:0]            flag_o;
    logic                  ready_o;
    logic [63:0]           data2rf;
    
    //      fp_hazard_unit
    logic                  stall_d;  
    logic                  flush_e;
    logic                  shift_reg_en;
    logic                  is_long_hazard;
    logic                  occupied;
    logic                  is_raw;
    logic [1:0]            fwd1sel;
    logic [1:0]            fwd2sel;
    logic [1:0]            fwd3sel;
    // DEC stage

    // Decode stage
    (* dont_touch = "true" *) reg_issue_decode reg_issue_decode (
        .clk(clk),
        .rst_n(rst_n),
        .en(stall_d),
        .instr_i(instr_i),
        .instr(instr)
    );

    (* dont_touch = "true" *) fp_control_unit fp_control_unit (
        .opcode(instr[6:0]),
        .funct(instr[31:27]),
        .fcvt_op(instr[24:20]),
        .rm(instr[14:12]),
        .fp_opcode(fp_opcode),
        .en(en),
        .reg_write(reg_write),
        .fmt_sel(fmt_sel),
        .rm_sel(rm_sel),
        .ld_sel(ld_sel),
        .wb_sel(wb_sel),
        .wren(wren),
        .shift_reg_addr(shift_reg_addr),
        .div_sqrt(div_sqrt),
        .bridge_wren(bridge_wren),
        .bridge_rden(bridge_rden)
    );
    assign readAddr1 = instr[19:15];
    assign readAddr2 = instr[24:20];
    assign readAddr3 = instr[31:27];

    (* dont_touch = "true" *) fp_regfile fp_regfile (
        .clk(clk),
        .reset(rst_n),
        .writeEn(reg_write_o),
        .writeAddr(writeAddr_o),
        .writeData(writeData),
        .readAddr1(readAddr1),
        .readAddr2(readAddr2),
        .readAddr3(readAddr3),
        .readData1(readData1),
        .readData2(readData2),
        .readData3(readData3),
        .readData4(readData4)               //Output cua reg[6]
    );

    (* dont_touch = "true" *) mux2_1 #(.DataWidth(12)) mux2_to_1_sign_extend (
        .inpA(instr[31:20]),
        .inpB({instr[31:25], instr[11:7]}),
        .sel(instr[5]),
        .outp(in_sign_extend)
    );

    (* dont_touch = "true" *)fp_sign_extend fp_sign_extend (
        .in(in_sign_extend),
        .out(out_sign_extend)
    );

    // Execute stage
    (* dont_touch = "true" *) reg_decode_execute reg_decode_execute (
        .clk(clk),
        .rst_n(rst_n),
        .sclr(flush_e),
        .fp_opcode(fp_opcode),
        .en(en),
        .fmt_sel(fmt_sel),
        .rm_sel(rm_sel),
        .wb_sel(wb_sel),
        .wren(wren),
        .writeAddr(instr[11:7]),
        .rm(instr[14:12]),
        .fmtLS({instr[14], instr[12]}),
        .fmt(instr[26:25]),
        .rdData1(readData1),
        .rdData2(readData2),
        .rdData3(readData3),
        .dyn_rm(3'b000),    // TODO: temp
        .imm(out_sign_extend),
        .rdAddr1(readAddr1),
        .rdAddr2(readAddr2),
        .rdAddr3(readAddr3),
        .bridge_wren(bridge_wren),
        .fp_opcode_d(fp_opcode_d),
        .en_d(en_d),
        .fmt_sel_d(fmt_sel_d),
        .rm_sel_d(rm_sel_d),
        .wb_sel_d(wb_sel_d),
        .wren_d(wren_d),
        .writeAddr_d(writeAddr_d),
        .rm_d(rm_d),
        .fmtLS_d(fmtLS_d),
        .fmt_d(fmt_d),
        .rdData1_d(rdData1_d),
        .rdData2_d(rdData2_d),
        .rdData3_d(rdData3_d),
        .dyn_rm_d(dyn_rm_d),
        .imm_d(imm_d),
        .rdAddr1_d(rdAddr1_d),
        .rdAddr2_d(rdAddr2_d),
        .rdAddr3_d(rdAddr3_d),
        .bridge_wren_d(bridge_wren_d)
    );

    (* dont_touch = "true" *)fp_shift_register fp_shift_register (
        .clk(clk),
        .rst_n(rst_n),
        .enable(shift_reg_en),
        .shift_reg_addr(shift_reg_addr),
        .div_sqrt(div_sqrt),
        .reg_write_d(reg_write),
        .writeAddr_d(instr[11:7]),
        .ld_sel_d(ld_sel),
        .wb_sel_d(wb_sel),
        .wren_d(wren),
        .opcode_d(fp_opcode),
        .rdAddr1_d(readAddr1),
        .rdAddr2_d(readAddr2),
        .rdAddr3_d(readAddr3),
        .reg_write_e(reg_write_e),
        .writeAddr_e(writeAddr_e),
        .ld_sel_e(ld_sel_e),
        .wb_sel_e(wb_sel_e),
        .wren_e(wren_e),
        .is_long_hazard(is_long_hazard),
        .occupied(occupied),
        .is_raw(is_raw)
    );

    (* dont_touch = "true" *) mux2_1 #(.DataWidth(2)) mux2_to_1_fmt_alu (
        .inpA(fmtLS_d),
        .inpB(fmt_d),
        .sel(fmt_sel_d),
        .outp(fmt)
    );
    
    
    (* dont_touch = "true" *) mux2_1 #(.DataWidth(3)) mux2_to_1_rm_alu (
        .inpA(rm_d),
        .inpB(dyn_rm_d),
        .sel(rm_sel_d),
        .outp(rm)
    );
    
    
    (* dont_touch = "true" *) mux3_1 #(.DataWidth(64)) mux3_to_1_data1_alu (
        .inpA(rdData1_d),
        .inpB(res_m),
        .inpC(writeData),
        .sel(fwd1sel),
        .outp(data1)
    );
    
    
    (* dont_touch = "true" *) mux3_1 #(.DataWidth(64)) mux3_to_1_data2_alu (
        .inpA(rdData2_d),
        .inpB(res_m),
        .inpC(writeData),
        .sel(fwd2sel),
        .outp(data2)
    );
    
    
    (* dont_touch = "true" *) mux3_1 #(.DataWidth(64)) mux3_to_1_data3_alu (
        .inpA(rdData3_d),
        .inpB(res_m),
        .inpC(writeData),
        .sel(fwd3sel),
        .outp(data3)
    );

    assign fp_unit_i.fp_exe_i = '{
        data1:  data1,
        data2:  data2,
        data3:  data3,
        op:     fp_opcode_d,
        fmt:    fmt,
        rm:     rm,
        enable: en_d
    };

    (* dont_touch = "true" *) fp_alu fp_alu (
        .clock(clk),
        .reset(rst_n),
        .fp_unit_i(fp_unit_i),
        .fp_unit_o(fp_unit_o)
    );

    assign result = fp_unit_o.fp_exe_o.result;
    assign flags  = fp_unit_o.fp_exe_o.flags;
    assign ready  = fp_unit_o.fp_exe_o.ready;

    (* dont_touch = "true" *) fp_adder fp_adder (
        .a(result),
        .b(imm_d),
        .sum(imm_e)
    );

    // Memory access stage
    (* dont_touch = "true" *) reg_execute_mem reg_execute_mem (
        .clk(clk),
        .rst_n(rst_n),
        .reg_write_e(reg_write_e),
        .writeAddr_e(writeAddr_e),
        .ld_sel_e(ld_sel_e),
        .wb_sel_e(wb_sel_e),
        .wren_e(wren_e),
        .res_e(result),
        .flags_e(flags),
        .ready_e(ready),
        .data2mem(data2),
        .imm_e(imm_e),
        .bridge_wren_e(bridge_wren_d),
        .reg_write_m(reg_write_m),
        .writeAddr_m(writeAddr_m),
        .ld_sel_m(ld_sel_m),
        .wb_sel_m(wb_sel_m),
        .wren_m(wren_m),
        .res_m(res_m),
        .flag_m(flag_m),
        .ready_m(ready_m),
        .din(din),
        .addr(addr),
        .bridge_wren_m(bridge_wren_m)
    );

    (* dont_touch = "true" *) fp_lsu fp_lsu (
        .clk(clk),
        .rst_n(rst_n),
        .ld_sel(ld_sel_m),
        .wren(wren_m),
        .addr(addr[13:0]),  
        .din(din),
        .dout(mem2lsu)
    );

    // WB stage
    (* dont_touch = "true" *) reg_mem_wb reg_mem_wb (
        .clk(clk),
        .rst_n(rst_n),
        .reg_write_w(reg_write_m),
        .writeAddr_w(writeAddr_m),
        .wb_sel_w(wb_sel_m),
        .res_w(res_m),
        .flag_w(flag_m),
        .ready_w(ready_m),
        .mem2lsu(mem2lsu),
        .reg_write_o(reg_write_o),
        .writeAddr_o(writeAddr_o),
        .wb_sel_o(wb_sel_o),
        .res_o(res_o),
        .flag_o(flag_o),
        .ready_o(ready_o),
        .data2rf(data2rf)
    );

    (* dont_touch = "true" *) mux2_1 #(.DataWidth(64)) mux2_to_1_writeData(
        .inpA(res_o),
        .inpB(data2rf),
        .sel(wb_sel_o),
        .outp(writeData)
    );

    (* dont_touch = "true" *) fp_hazard_unit fp_hazard_unit (
        .clk(clk),
        .rstn(rst_n),
        .wren_d(wren),
        .opcode_d(fp_opcode),
        .rdAddr1_d(readAddr1),
        .rdAddr2_d(readAddr2),
        .rdAddr3_d(readAddr3),
        .wb_sel_e(wb_sel_d),
        .opcode_e(fp_opcode_d),
        .rdAddr1_e(rdAddr1_d),
        .rdAddr2_e(rdAddr2_d),
        .rdAddr3_e(rdAddr3_d),
        .writeAddr_e(writeAddr_d),
        .wren_e(wren_d),
        .reg_write_m(reg_write_m),
        .writeAddr_m(writeAddr_m),
        .bridge_wren_m(bridge_wren_m),
        .reg_write_w(reg_write_o),
        .writeAddr_w(writeAddr_o),
        .is_long_hazard(is_long_hazard),
        .occupied(occupied),
        .is_raw(is_raw),
        .stall_i(stall_i),
        .stall_d(stall_d),
        .flush_e(flush_e),
        .fwd1sel(fwd1sel),
        .fwd2sel(fwd2sel),
        .fwd3sel(fwd3sel),
        .shift_reg_en(shift_reg_en)
    );

endmodule
