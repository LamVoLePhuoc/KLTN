register_map = {f"fr{i}": i for i in range(32)}

# Mapping rounding mode từ chuỗi -> binary (3-bit)
rounding_mode_map = {
    "RNE": "000",
    "RTZ": "001",
    "RDN": "010",
    "RUP": "011",
    "RMM": "100",
    "DYN": "111"
}

# Định nghĩa các lệnh và thông số mã hóa
instruction_map = {
    # Load/Store
    "FLD": {"opcode": "0000111", "funct3": "011", "type": "I"},
    "FSD": {"opcode": "0100111", "funct3": "011", "type": "S"},

    # Fused Multiply-Add (FMA) với định dạng R4 có RM
    "FMADD.D":  {"opcode": "1000011", "funct2": "01", "type": "R4"},
    "FMSUB.D":  {"opcode": "1000111", "funct2": "01", "type": "R4"},
    "FNMSUB.D": {"opcode": "1001011", "funct2": "01", "type": "R4"},
    "FNMADD.D": {"opcode": "1001111", "funct2": "01", "type": "R4"},

    # Basic FP operations có trường RM
    "FADD.D": {"opcode": "1010011", "funct7": "0000001", "type": "R_rm"},
    "FSUB.D": {"opcode": "1010011", "funct7": "0000101", "type": "R_rm"},
    "FMUL.D": {"opcode": "1010011", "funct7": "0001001", "type": "R_rm"},
    "FDIV.D": {"opcode": "1010011", "funct7": "0001101", "type": "R_rm"},
    "FSQRT.D": {"opcode": "1010011", "funct7": "0101101", "type": "RS1_rm"},  # rs2 = 0

    # FSGNJ operations (không cần rm)
    "FSGNJ.D":  {"opcode": "1010011", "funct7": "0010001", "funct3": "000", "type": "R"},
    "FSGNJN.D": {"opcode": "1010011", "funct7": "0010001", "funct3": "001", "type": "R"},
    "FSGNJX.D": {"opcode": "1010011", "funct7": "0010001", "funct3": "010", "type": "R"},

    # Min/Max
    "FMIN.D": {"opcode": "1010011", "funct7": "0010101", "funct3": "000", "type": "R"},
    "FMAX.D": {"opcode": "1010011", "funct7": "0010101", "funct3": "001", "type": "R"},

    # Compare
    "FEQ.D": {"opcode": "1010011", "funct7": "1010001", "funct3": "010", "type": "R"},
    "FLT.D": {"opcode": "1010011", "funct7": "1010001", "funct3": "001", "type": "R"},
    "FLE.D": {"opcode": "1010011", "funct7": "1010001", "funct3": "000", "type": "R"},

    # Convert operations, có trường RM
    "FCVT.W.D":  {"opcode": "1010011", "funct7": "1100001", "rs2": "00000", "type": "RCVT_rm"},
    "FCVT.WU.D": {"opcode": "1010011", "funct7": "1100001", "rs2": "00001", "type": "RCVT_rm"},
    "FCVT.D.W":  {"opcode": "1010011", "funct7": "1101001", "rs2": "00000", "type": "RCVT_rm"},
    "FCVT.D.WU": {"opcode": "1010011", "funct7": "1101001", "rs2": "00001", "type": "RCVT_rm"},
    "FCVT.S.D":  {"opcode": "1010011", "funct7": "0100000", "rs2": "00001", "type": "RCVT_rm"},
    "FCVT.D.S":  {"opcode": "1010011", "funct7": "0100001", "rs2": "00000", "type": "RCVT_rm"},
    "FCVT.L.D":  {"opcode": "1010011", "funct7": "1100001", "rs2": "00010", "type": "RCVT_rm"},
    "FCVT.LU.D": {"opcode": "1010011", "funct7": "1100001", "rs2": "00011", "type": "RCVT_rm"},
    "FCVT.D.L":  {"opcode": "1010011", "funct7": "1101001", "rs2": "00010", "type": "RCVT_rm"},
    "FCVT.D.LU": {"opcode": "1010011", "funct7": "1101001", "rs2": "00011", "type": "RCVT_rm"},

    # Move operations (chuyển đổi giữa FP và int)
    "FMV.X.D": {"opcode": "1010011", "funct7": "1110001", "rs2": "00000", "type": "RCVT_rm"},
    "FMV.D.X": {"opcode": "1010011", "funct7": "1111001", "rs2": "00000", "type": "RCVT_rm"},

    # Classify
    "FCLASS.D": {"opcode": "1010011", "funct7": "1110001", "rs2": "00001", "type": "RCVT_norm"}
}

def to_bin(val, bits):
    """Chuyển số nguyên thành chuỗi nhị phân có độ dài cố định"""
    if val < 0:
        val = (1 << bits) + val
    return format(val, f"0{bits}b")

def to_hex(binstr):
    """Chuyển chuỗi nhị phân thành dạng HEX 32-bit"""
    return f"32'h{int(binstr, 2):08x}"

def encode_instruction(instr, rm_bin):
    tokens = instr.replace(",", "").split()
    mnemonic = tokens[0].upper()
    if mnemonic not in instruction_map:
        raise ValueError(f"Unknown instruction: {mnemonic}")
    spec = instruction_map[mnemonic]

    # Format các lệnh khác nhau
    if spec["type"] == "I":
        # I-type: imm[11:0] | rs1 | funct3 | rd | opcode
        rd = register_map[tokens[1]]
        offset, rs1 = tokens[2].split("(")
        rs1 = register_map[rs1[:-1]]
        imm = int(offset)
        return to_hex(
            to_bin(imm, 12) +
            to_bin(rs1, 5) +
            spec["funct3"] +
            to_bin(rd, 5) +
            spec["opcode"]
        )

    elif spec["type"] == "S":
        # S-type: imm[11:5] | rs2 | rs1 | funct3 | imm[4:0] | opcode
        rs2 = register_map[tokens[1]]
        offset, rs1 = tokens[2].split("(")
        rs1 = register_map[rs1[:-1]]
        imm = to_bin(int(offset), 12)
        return to_hex(
            imm[:7] +
            to_bin(rs2, 5) +
            to_bin(rs1, 5) +
            spec["funct3"] +
            imm[7:] +
            spec["opcode"]
        )

    elif spec["type"] == "R":
        # R-type: funct7 | rs2 | rs1 | funct3 | rd | opcode
        rd = register_map[tokens[1]]
        rs1 = register_map[tokens[2]]
        rs2 = register_map[tokens[3]]
        return to_hex(
            spec["funct7"] +
            to_bin(rs2, 5) +
            to_bin(rs1, 5) +
            spec["funct3"] +
            to_bin(rd, 5) +
            spec["opcode"]
        )

    elif spec["type"] == "R_rm":
        # R-type có rm field: funct7 | rs2 | rs1 | rm | rd | opcode
        rd = register_map[tokens[1]]
        rs1 = register_map[tokens[2]]
        rs2 = register_map[tokens[3]]
        return to_hex(
            spec["funct7"] +
            to_bin(rs2, 5) +
            to_bin(rs1, 5) +
            rm_bin +
            to_bin(rd, 5) +
            spec["opcode"]
        )

    elif spec["type"] == "RS1_rm":
        # Ví dụ: FSQRT.D: rs2 = 0 luôn, dùng rm field
        rd = register_map[tokens[1]]
        rs1 = register_map[tokens[2]]
        rs2 = 0
        return to_hex(
            spec["funct7"] +
            to_bin(rs2, 5) +
            to_bin(rs1, 5) +
            rm_bin +
            to_bin(rd, 5) +
            spec["opcode"]
        )

    elif spec["type"] == "RCVT_rm":
        # Convert operations dạng R với rm field: funct7 | rs2 (fixed) | rs1 | rm | rd | opcode
        rd = register_map[tokens[1]]
        rs1 = register_map[tokens[2]]
        rs2 = int(spec["rs2"], 2)
        return to_hex(
            spec["funct7"] +
            to_bin(rs2, 5) +
            to_bin(rs1, 5) +
            rm_bin +
            to_bin(rd, 5) +
            spec["opcode"]
        )

    elif spec["type"] == "RCVT_norm":
        # Những lệnh không cần rm (vd: FCLASS.D): funct7 | rs2 | rs1 | 000 | rd | opcode
        rd = register_map[tokens[1]]
        rs1 = register_map[tokens[2]]
        rs2 = int(spec["rs2"], 2)
        return to_hex(
            spec["funct7"] +
            to_bin(rs2, 5) +
            to_bin(rs1, 5) +
            "000" +
            to_bin(rd, 5) +
            spec["opcode"]
        )

    elif spec["type"] == "R4":
        # R4-type cho FMA:
        # Format: rs3 (5) | rs2 (5) | rs1 (5) | rm (3) | rd (5) | opcode (7)
        rd  = register_map[tokens[1]]
        rs1 = register_map[tokens[2]]
        rs2 = register_map[tokens[3]]
        rs3 = register_map[tokens[4]]
        return to_hex(
            to_bin(rs3, 5) +
            spec["funct2"] +
            to_bin(rs2, 5) +
            to_bin(rs1, 5) +
            rm_bin +
            to_bin(rd, 5) +
            spec["opcode"]
        )

    else:
        raise ValueError(f"Unsupported instruction format for {mnemonic}")

def read_instructions_from_file(filename):
    with open(filename, "r") as f:
        # Mỗi dòng không rỗng và không comment
        return [line.strip() for line in f if line.strip() and not line.startswith("#")]

def write_hex_to_file(hex_list, filename):
    with open(filename, "w") as f:
        for h in hex_list:
            f.write(h + "\n")

if __name__ == "__main__":
    input_file = "../test/input_instr.txt"
    output_file = "../test/output_machine_code_instr.txt"
    rm = input("Chọn rounding mode (RNE, RTZ, RDN, RUP, RMM, DYN): ").strip().upper()

    if rm not in rounding_mode_map:
        print("❌ Rounding mode không hợp lệ.")
        exit(1)

    rm_bin = rounding_mode_map[rm]

    try:
        instructions = read_instructions_from_file(input_file)
        hex_codes = [encode_instruction(instr, rm_bin) for instr in instructions]
        write_hex_to_file(hex_codes, output_file)
        print(f"✅ Đã chuyển {len(hex_codes)} dòng lệnh sang mã máy (định dạng HEX) với rounding mode = {rm} → {output_file}")
    except Exception as e:
        print("❌ Lỗi:", e)
