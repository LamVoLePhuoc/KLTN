import random
import struct
import math

random.seed(42)

random_count = 1000
special_count = 130
output_hex = "../test/fp_memory_backdoor.hex"
output_log = "../test/fp_memory_backdoor_real.log"

open(output_hex, "w").close()
open(output_log, "w").close()

def double_to_hex(f):
    return struct.pack('>d', f).hex()

def write_entry(index, value, hex_file, real_file, label=None):
    hex_index = f"{index:X}"  # hoặc "{index:X}" nếu không cần 0-padding
    hex_str = double_to_hex(value)
    hex_file.write(f"{hex_index}:{hex_str}\n")

    if label:
        real_file.write(f"{hex_index}:{label}\n")
    elif math.isnan(value):
        real_file.write(f"{hex_index}:NaN\n")
    elif math.isinf(value):
        real_file.write(f"{hex_index}:{'+Inf' if value > 0 else '-Inf'}\n")
    else:
        real_file.write(f"{hex_index}:{value:.20f}\n")

def generate_log_uniform(min_exp, max_exp):
    log_val = random.uniform(min_exp, max_exp)
    base_val = 10 ** log_val
    sign = random.choice([-1, 1])
    return sign * base_val

def generate_special_values():
    specials = []

    specials.append((float('inf'), '+Inf'))
    specials.append((float('-inf'), '-Inf'))

    qnan_pos = struct.unpack('>d', bytes.fromhex("7FF8000000000001"))[0]
    qnan_neg = struct.unpack('>d', bytes.fromhex("FFF8000000000001"))[0]
    specials.append((qnan_pos, 'qNaN'))
    specials.append((qnan_neg, 'qNaN'))

    snan_pos = struct.unpack('>d', bytes.fromhex("7FF0000000000001"))[0]
    snan_neg = struct.unpack('>d', bytes.fromhex("FFF0000000000001"))[0]
    specials.append((snan_pos, 'sNaN'))
    specials.append((snan_neg, 'sNaN'))

    while len(specials) < special_count:
        specials.append(random.choice(specials))
    return specials[:special_count]

with open(output_hex, "w") as hex_file, open(output_log, "w") as real_file:
    min_exp, max_exp = -10, 10

    special_indices = sorted(random.sample(range(random_count), special_count))
    specials = generate_special_values()
    special_iter = iter(specials)

    index = 0
    for i in range(random_count):
        if index in special_indices:
            value, label = next(special_iter)
            write_entry(index, value, hex_file, real_file, label)
        else:
            value = generate_log_uniform(min_exp, max_exp)
            write_entry(index, value, hex_file, real_file)
        index += 1
