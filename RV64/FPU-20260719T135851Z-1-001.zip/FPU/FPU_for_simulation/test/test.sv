`include "../top_module/fp_top.sv"

module test;
    timeunit 1ns; timeprecision 1ps;
    
    logic clk, reset;
    logic [31:0] instr_i;
    logic stall_i;
    longint unsigned clock_counter;

    fp_top dut (
        .clk(clk),
        .rst_n(reset),
        .instr_i(instr_i),
        .stall_i(stall_i)
    );

    always #5 clk = ~clk;

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, test);
        clk = 1'b0;
        reset = 1'b0;
        instr_i = '0;
        #8 reset = 1'b1; 
        
        // issue_cmd(32'h0012b487);
        // issue_cmd(32'h0044b087);
        // issue_cmd(32'h0214a153);
        // issue_cmd(32'h0a2222d3);
        // issue_cmd(32'h0a20a4c3);
        // @(posedge clk);
        // issue_cmd(32'h1a22a353);
        // issue_cmd(32'h2a1483d3);
        // issue_cmd(32'h4a51224b);
        // issue_cmd(32'h2a631453);
        issue_cmd(32'h1a22c353);
        issue_cmd(32'h0012b487);
        issue_cmd(32'h2a1483d3);
        issue_cmd(32'h4a51424b);
        issue_cmd(32'h2a631453);
        issue_cmd(32'hz);
        repeat (1000) begin
            @(posedge clk);
        end
        $finish;
    end

    initial begin
        @(posedge reset);
        forever @(posedge clk) begin
            clock_counter++;
        end
    end

    task automatic issue_cmd(logic [31:0] instr);
        @(posedge clk);
        instr_i <= instr;
        #1;
        if (stall_i) begin
            @(posedge clk);
        end
    endtask: issue_cmd
endmodule
