module reg_issue_decode(
    input logic         clk,
    input logic         rst_n,
    input logic         en,

    input logic [31:0]  instr_i,
    output logic [31:0]  instr
);
    timeunit 1ns; timeprecision 1ps;
    
    logic [31:0] instr_temp;

    always_ff @(posedge clk, negedge rst_n) begin
        if (rst_n == 1'b0) begin
            instr_temp <= '0;
        end
        else if (en == 1'b0) begin
            instr_temp <= instr_i;
        end
        else begin
            instr_temp <= instr_temp;
        end
    end

    assign instr = instr_temp;

endmodule: reg_issue_decode