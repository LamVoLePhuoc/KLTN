1) Khởi tạo memory:
	- cd vào directory "test"
	- Chạy lệnh: python3 float_gen.py, chương trình sẽ khởi tạo 2 file: 
		+ fp_memory_backdoor.hex: file bộ nhớ data dưới dạng mã HEX
		+ fp_memory_backdoor_real.log: file bộ nhớ dùng để người dùng đọc và debug, được biểu diễn dưới dạng số thực với giá trị tương ứng bên file .hex

2) Chuyển đổi lệnh chữ thành mã HEX:
	- cd vào directory "test", ghi lệnh vào input_instr.txt
	- Chạy lệnh: python3 machine_code_convertor.py
	- Chọn chế độ rounding mode
	- Chương trình sẽ chuyển đổi lệnh chữ từ input_instr.txt thành mã HEX được lưu vào file output_machine_code_instr.txt

3) Chạy testbench:
	- cd vào directory "run"
	- Copy thứ tự các lệnh vào file testbench thông qua hàm issue_cmd
	- Chạy lệnh:
		+ Đối với tool Xcelium: xrun ../test/test.sv +access+r
		+ Đối với tool Siemens Questa: qverilog ../test/test.sv -access -r
		+ Đối với tool Synopsys VCS: vcs -full64 -licqueue '-timescale=1ns/1ns' '+vcs+flush+all' '+warn=all' '-sverilog' ../test/test.sv && ./simv +vcs+lic+wait