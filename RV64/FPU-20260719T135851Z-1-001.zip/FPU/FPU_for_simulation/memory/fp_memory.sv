module fp_lsu #(
    parameter   DATA_WIDTH = 64,
    parameter   ADDR_WIDTH = 14
) (
    input  logic                  clk,
    input  logic                  rst_n,
    input  logic                  ld_sel,
    input  logic                  wren,
    input  logic [ADDR_WIDTH-1:0] addr,
    input  logic [DATA_WIDTH-1:0] din,
    output logic [DATA_WIDTH-1:0] dout
);
    timeunit 1ns; timeprecision 1ps;

    fp_ram #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) ram (
        .clk(clk),
        .rst_n(rst_n),
        .we(wren),
        .re(ld_sel),
        .addr(addr),
        .data_in(din),
        .data_out(dout)
    );

endmodule

module fp_ram #(
    parameter DATA_WIDTH = 64,
    parameter ADDR_WIDTH = 14
) (
    input  logic                  clk,
    input  logic                  rst_n,
    input  logic                  we,
    input  logic                  re,
    input  logic [ADDR_WIDTH-1:0] addr,
    input  logic [DATA_WIDTH-1:0] data_in,
    output logic [DATA_WIDTH-1:0] data_out
);

    timeunit 1ns; timeprecision 1ps;

    integer debug_fhandle;  // For debug log

    logic [DATA_WIDTH-1:0] mem [(2**ADDR_WIDTH)];

    logic [DATA_WIDTH-1:0] temp;

    initial begin
        debug_fhandle = $fopen($sformatf("%s", "memory_debug_log.log"), "w");

        $fdisplay(debug_fhandle, "===============================================================================================");
        $fdisplay(debug_fhandle, "===============================================================================================");
        $fdisplay(debug_fhandle, "                                          MEMORY LOGS                                          ");
        $fdisplay(debug_fhandle, "===============================================================================================");
        $fdisplay(debug_fhandle, "===============================================================================================");

        load_backdoor_values(debug_fhandle);
    end
    
    always_ff @(posedge clk) begin
        /*if (!rst_n) begin
            load_backdoor_values(debug_fhandle);
        end
        else */if (we && (addr < (2**ADDR_WIDTH))) begin    // Using backdoor instead of reset
            mem[addr] <= data_in;
        end
    end
    
    always_ff @(negedge clk) begin  // Temporary method of using negedge
        if (we) begin
            temp <= temp;
        end
        else if (re) begin
            temp <= mem[addr];
        end
        else begin
            temp <= '0;
        end
    end
    
    assign data_out = temp;

    function automatic void load_backdoor_values(integer debug_fhandle);
        int fp;                                        // String pointer
        integer code;                   
        string fname;                                  // File name
        string str;                                    // Variable to hold current string
        string temp_str;                               // Temporary string
    
        // Store file path
        fname = "../test/fp_memory_backdoor.hex";
        fp = $fopen(fname, "r");                       // Open HEX file in reading mode
    
        if (fp) begin
            $fdisplay(debug_fhandle, "LINE = %5d ", `__LINE__, $sformatf("[MEMORY] === Success to open %s", fname));
            code = $fgets(temp_str, fp);               // Get the first line in the file
            str = "";                                  // Reset the string
            foreach (temp_str[i]) begin                // Truncate the "\n", " ", tab character
                if (!(temp_str[i] inside {9, 10, 32})) begin
                    str = $sformatf("%s%s", str, temp_str[i]);
                end
            end
        end
        else begin
            $fdisplay(debug_fhandle, "LINE = %5d ", `__LINE__, $sformatf("[MEMORY] === NOT able to open %s", fname));
            $warning($sformatf("@%0t [MEMORY] === NOT able to open %s", $realtime, fname));
        end
    
        while (temp_str != "") begin
            $fdisplay(debug_fhandle, "LINE = %5d ", `__LINE__, $sformatf("[MEMORY] === Calling load_ram_from_input_custom_string with string: %s", str));
            load_ram_from_input_custom_string(str, debug_fhandle);    // Call function automatic to extract string to data
            code = $fgets(temp_str, fp);               // Keep getting the remaining lines of the file
            str = "";                                  // Reset the string
            foreach (temp_str[i]) begin                // Truncate the "\n", " ", tab character
                if (!(temp_str[i] inside {9, 10, 32})) begin
                    str = $sformatf("%s%s", str, temp_str[i]);
                end
            end
        end
    
        $fclose(fp);                                   // Close HEX file
    endfunction: load_backdoor_values
    
    function automatic void load_ram_from_input_custom_string(string str, integer debug_fhandle);
        string str_addr;                               // String to hold address
        string str_data;                               // String to hold data

        bit [(ADDR_WIDTH-1):0] addr;                   // Variable to hold address
        bit [(DATA_WIDTH-1):0] data;                   // Variable to hold data
    
        bit delimiter_found;                           // Flag to notify the boundary between address and data
    
        $fdisplay(debug_fhandle, "LINE = %5d ", `__LINE__, $sformatf("[MEMORY] === String length: %0d", str.len()));
    
        foreach (str[i]) begin
            if (str[i] == ":") begin                   // Skip the ":" and notify that the boundary has been found
                delimiter_found = 1;
                continue;
            end
            
            if (!delimiter_found) begin                // Extract the address, which is before the boundary
                str_addr = $sformatf("%s%s", str_addr, str[i]);
            end
            else begin                                 // Extract the data, which is after the boundary
                str_data = $sformatf("%s%s", str_data, str[i]);
            end
        end

        void'($sscanf(str_addr, "%h", addr));
        void'($sscanf(str_data, "%h", data));
    
        $fdisplay(debug_fhandle, "LINE = %5d ", `__LINE__, $sformatf("[MEMORY] === Information from HEX file with Address: 'd%0d, Data: 0x%0h", addr, data));
    
        // Call the function automatic to update data to corresponding register
        update_ram_values(addr, data, debug_fhandle);
    endfunction: load_ram_from_input_custom_string
    
    function automatic void update_ram_values(int addr, bit [63:0] data, integer debug_fhandle);
        mem[addr] = data;
        $fdisplay(debug_fhandle, "LINE = %5d ", `__LINE__, $sformatf("[MEMORY] === Updated data for mem[%0d] = 0x%0h", addr, mem[addr]));
    endfunction: update_ram_values

endmodule