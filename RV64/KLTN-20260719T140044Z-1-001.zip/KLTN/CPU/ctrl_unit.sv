module ctrl_unit (
    input [31:0] instr,
    input br_less, br_equal,
    output logic br_sel, rd_wren, br_unsigned, op_a_sel, op_b_sel, mem_wren, mem_lden, W_suffix, ex_res_sel,
    output logic [1:0] wb_sel, muldiv_op, muldiv_mode,
    output logic [2:0] ld_sel,
    output logic [3:0] alu_op, byte_en
);
    timeunit 1ns; timeprecision 1ps;
    
    logic [6:0] opcode, funct7;
    logic [2:0] funct3;

    assign opcode = instr[6:0];
    assign funct3 = instr[14:12];
    assign funct7 = instr[31:25];

    localparam LUI    = 7'b0110111;
    localparam AUIPC  = 7'b0010111;
    localparam JAL    = 7'b1101111;
    localparam JALR   = 7'b1100111;
    localparam B      = 7'b1100011;
    localparam L      = 7'b0000011;
    localparam S      = 7'b0100011;
    localparam LSD    = 3'b011;
    localparam LSW    = 3'b010;
    localparam LSWU   = 3'b110;
    localparam LSB    = 3'b000;
    localparam LSH    = 3'b001;
    localparam LBU    = 3'b100;
    localparam LHU    = 3'b101;
    localparam I      = 7'b0010011;
    localparam IW     = 7'b0011011;
    localparam R      = 7'b0110011;
    localparam RW     = 7'b0111011;
    localparam Rf7    = 7'b0000000;
    localparam Rf7n   = 7'b0100000;
    localparam Rf7m   = 7'b0000001;
    localparam EQ     = 3'b000;
    localparam NE     = 3'b001;
    localparam LT     = 3'b100;
    localparam GE     = 3'b101;
    localparam LTU    = 3'b110;
    localparam GEU    = 3'b111;
    localparam ADDs   = 3'b000;
    localparam SLLs   = 3'b001;
    localparam SLTs   = 3'b010;
    localparam SLTUs  = 3'b011;
    localparam XORs   = 3'b100;
    localparam SRs    = 3'b101;
    localparam ORs    = 3'b110;
    localparam ANDs   = 3'b111;
    localparam MUL    = 3'b000;
    localparam MULH   = 3'b001;
    localparam MULHSU = 3'b010;
    localparam MULHU  = 3'b011;
    localparam DIV    = 3'b100;
    localparam DIVU   = 3'b101;
    localparam REM    = 3'b110;
    localparam REMU   = 3'b111;

    always_comb
        //#############################################################################################################
        // LUI
        //#############################################################################################################
        if (opcode == LUI)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // AUIPC
        //#############################################################################################################
        if (opcode == AUIPC)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // JAL
        //#############################################################################################################
        if (opcode == JAL)
        begin
            br_sel = 1; rd_wren = 1; br_unsigned = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 2;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // JALR
        //#############################################################################################################
        if (opcode == JALR && funct3 == 3'b000)
        begin
            br_sel = 1; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 2;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // BEQ
        //############################################################################################################
        if (opcode == B && funct3 == EQ)
        begin
            if (br_equal)
            begin
                br_sel = 1; rd_wren = 0; br_unsigned = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
            else
            begin
                br_sel = 0; rd_wren = 0; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
        end
        else
        //#############################################################################################################
        // BNE
        //#############################################################################################################
        if (opcode == B && funct3 == NE)
        begin
            if (!br_equal)
            begin
                br_sel = 1; rd_wren = 0; br_unsigned = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
            else
            begin
                br_sel = 0; rd_wren = 0; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
        end
        else
        //#############################################################################################################
        // BLT
        //#############################################################################################################
        if (opcode == B && funct3 == LT)
        begin
            br_unsigned = 0;
            if (br_less)
            begin
                br_sel = 1; rd_wren = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
            else
            begin
                br_sel = 0; rd_wren = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
        end
        else
        //#############################################################################################################
        // BGE
        //#############################################################################################################
        if (opcode == B && funct3 == GE)
        begin
            br_unsigned = 0;
            if ((!br_less && !br_equal) || br_equal)
            begin
                br_sel = 1; rd_wren = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
            else
            begin
                br_sel = 0; rd_wren = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
        end
        else
        //#############################################################################################################
        // BLTU
        //#############################################################################################################
        if (opcode == B && funct3 == LTU)
        begin
            br_unsigned = 1;
            if (br_less)
            begin
                br_sel = 1; rd_wren = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
            else
            begin
                br_sel = 0; rd_wren = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
        end
        else
        //#############################################################################################################
        // BGEU
        //#############################################################################################################
        if (opcode == B && funct3 == GEU)
        begin
            br_unsigned = 1;
            if ((!br_less && !br_equal) || br_equal)
            begin
                br_sel = 1; rd_wren = 0; op_a_sel = 1; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
            else
            begin
                br_sel = 0; rd_wren = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
                byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
            end
        end
        else
        //#############################################################################################################
        // LB
        //#############################################################################################################
        if (opcode == L && funct3 == LSB)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 1; wb_sel = 1;
            byte_en = 4'b0000; ld_sel = 2; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // LH
        //#############################################################################################################
        if (opcode == L && funct3 == LSH)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 1; wb_sel = 1;
            byte_en = 4'b0000; ld_sel = 4; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // LBU
        //#############################################################################################################
        if (opcode == L && funct3 == LBU)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 1; wb_sel = 1;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // LHU
        //#############################################################################################################
        if (opcode == L && funct3 == LHU)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 1; wb_sel = 1;
            byte_en = 4'b0000; ld_sel = 1; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // LW
        //#############################################################################################################
        if (opcode == L && funct3 == LSW)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 1; wb_sel = 1;
            byte_en = 4'b0000; ld_sel = 6; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SB
        //#############################################################################################################
        if (opcode == S && funct3 == LSB)
        begin
            br_sel = 0; rd_wren = 0; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 1; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0001; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SH
        //#############################################################################################################
        if (opcode == S && funct3 == LSH)
        begin
            br_sel = 0; rd_wren = 0; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 1; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0011; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SW
        //#############################################################################################################
        if (opcode == S && funct3 == LSW)
        begin
            br_sel = 0; rd_wren = 0; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 1; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b1111; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SD
        //#############################################################################################################
        if (opcode == S && funct3 == LSD)
        begin
            br_sel = 0; rd_wren = 0; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 1; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0111; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // ADDI
        //#############################################################################################################
        if (opcode == I && funct3 == ADDs)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - ADDIW
        //#############################################################################################################
        if (opcode == IW && funct3 == ADDs)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SLTI
        //#############################################################################################################
        if (opcode == I && funct3 == SLTs)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 2; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SLTIU
        //#############################################################################################################
        if (opcode == I && funct3 == SLTUs)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 3; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // XORI
        //#############################################################################################################
        if (opcode == I && funct3 == XORs)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 4; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // ORI
        //#############################################################################################################
        if (opcode == I && funct3 == ORs)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 5; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // ANDI
        //#############################################################################################################
        if (opcode == I && funct3 == ANDs)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 6; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SLLI
        //#############################################################################################################
        if (opcode == I && funct3 == SLLs && funct7[6:1] == 6'b000000)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 7; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SLLIW
        //#############################################################################################################
        if (opcode == IW && funct3 == SLLs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 7; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SRLI
        //#############################################################################################################
        if (opcode == I && funct3 == SRs && funct7[6:1] == 6'b000000)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 8; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SRLIW
        //#############################################################################################################
        if (opcode == IW && funct3 == SRs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 8; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SRAI
        //#############################################################################################################
        if (opcode == I && funct3 == SRs && funct7[6:1] == 6'b010000)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 9; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SRAIW
        //#############################################################################################################
        if (opcode == IW && funct3 == SRs && funct7 == Rf7n)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 9; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // ADD
        //#############################################################################################################
        if (opcode == R && funct3 == ADDs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - ADDW
        //#############################################################################################################
        if (opcode == RW && funct3 == ADDs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SUB
        //#############################################################################################################
        if (opcode == R && funct3 == ADDs && funct7 == Rf7n)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 1; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SUBW
        //#############################################################################################################
        if (opcode == RW && funct3 == ADDs && funct7 == Rf7n)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 1; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SLT
        //#############################################################################################################
        if (opcode == R && funct3 == SLTs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 2; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SLTU
        //#############################################################################################################
        if (opcode == R && funct3 == SLTUs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 3; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // XOR
        //#############################################################################################################
        if (opcode == R && funct3 == XORs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 4; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // OR
        //#############################################################################################################
        if (opcode == R && funct3 == ORs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 5; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // AND
        //#############################################################################################################
        if (opcode == R && funct3 == ANDs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 6; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SLL
        //#############################################################################################################
        if (opcode == R && funct3 == SLLs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 7; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SLLW
        //#############################################################################################################
        if (opcode == RW && funct3 == SLLs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 7; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SRL
        //#############################################################################################################
        if (opcode == R && funct3 == SRs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 8; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SRLW
        //#############################################################################################################
        if (opcode == RW && funct3 == SRs && funct7 == Rf7)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 8; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // SRA
        //#############################################################################################################
        if (opcode == R && funct3 == SRs && funct7 == Rf7n)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 9; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - SRAW
        //#############################################################################################################
        if (opcode == RW && funct3 == SRs && funct7 == Rf7n)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 9; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - LWU
        //#############################################################################################################
        if (opcode == L && funct3 == LSWU)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 1; wb_sel = 1;
            byte_en = 4'b0000; ld_sel = 5; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // RV64 - LD
        //#############################################################################################################
        if (opcode == L && funct3 == LSD)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 1; alu_op = 0; mem_wren = 0; mem_lden = 1; wb_sel = 1;
            byte_en = 4'b0000; ld_sel = 3; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end
        else
        //#############################################################################################################
        // MUL
        //#############################################################################################################
        if (opcode == R && funct3 == MUL && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b01; muldiv_mode = 2'b00;
        end
        else
        //#############################################################################################################
        // MULH
        //#############################################################################################################
        if (opcode == R && funct3 == MULH && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b01; muldiv_mode = 2'b01;
        end
        else
        //#############################################################################################################
        // MULHSU
        //#############################################################################################################
        if (opcode == R && funct3 == MULHSU && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b01; muldiv_mode = 2'b10;
        end
        else
        //#############################################################################################################
        // MULHU
        //#############################################################################################################
        if (opcode == R && funct3 == MULHU && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b01; muldiv_mode = 2'b11;
        end
        else
        //#############################################################################################################
        // DIV
        //#############################################################################################################
        if (opcode == R && funct3 == DIV && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b00;
        end
        else
        //#############################################################################################################
        // DIVU
        //#############################################################################################################
        if (opcode == R && funct3 == DIVU && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b01;
        end
        else
        //#############################################################################################################
        // REM
        //#############################################################################################################
        if (opcode == R && funct3 == REM && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b10;
        end
        else
        //#############################################################################################################
        // REMU
        //#############################################################################################################
        if (opcode == R && funct3 == REMU && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b11;
        end
        else
        //#############################################################################################################
        // RV64 - MULW
        //#############################################################################################################
        if (opcode == RW && funct3 == MUL && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 1; muldiv_op = 2'b01; muldiv_mode = 2'b00;
        end
        else
        //#############################################################################################################
        // RV64 - DIVW
        //#############################################################################################################
        if (opcode == RW && funct3 == DIV && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b00;
        end
        else
        //#############################################################################################################
        // RV64 - DIVUW
        //#############################################################################################################
        if (opcode == RW && funct3 == DIVU && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b01;
        end
        else
        //#############################################################################################################
        // RV64 - REMW
        //#############################################################################################################
        if (opcode == RW && funct3 == REM && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b10;
        end
        else
        //#############################################################################################################
        // RV64 - REMUW
        //#############################################################################################################
        if (opcode == RW && funct3 == REMU && funct7 == Rf7m)
        begin
            br_sel = 0; rd_wren = 1; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 1; ex_res_sel = 1; muldiv_op = 2'b10; muldiv_mode = 2'b11;
        end
        //#############################################################################################################
        // none of the above
        //#############################################################################################################
        else
        begin
            br_sel = 0; rd_wren = 0; br_unsigned = 0; op_a_sel = 0; op_b_sel = 0; alu_op = 0; mem_wren = 0; mem_lden = 0; wb_sel = 0;
            byte_en = 4'b0000; ld_sel = 0; W_suffix = 0; ex_res_sel = 0; muldiv_op = 2'd0; muldiv_mode = 2'd0;
        end

endmodule